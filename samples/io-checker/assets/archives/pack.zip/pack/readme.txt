Inside pack.zip, mounted with love.filesystem.mount.
